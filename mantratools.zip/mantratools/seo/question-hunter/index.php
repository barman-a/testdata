<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<script src='../../assets/js/wait.js'></script>";
echo "<title>Question Hunter | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Question Hunter<h3>
    <h6>Find what people are asking<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<?php
if(isset($_POST['qhunt']))
{

$qhunt=$_POST['qhunt'];

}
?>

<div class="row">
<div class=" col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 ">

<form action="" method="post" onsubmit="waitmsg()" >
<div><h6>Input Keywords</h6></div>

<div class="input-group m-2" id="div1">
  <input type="text" id="qhunt" name="qhunt" placeholder="Enter keyword(s)" required class="form-control" style='width:40%;'value='<?php echo $qhunt; ?>'  />
  <div class="input-group-append">
  <input type='submit' value='Search Question' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs' />
  </div>
</div>

</form>
</div>


<div class=" col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 ">
<p> Question explorer tool allows you to find questions that are being asked on the internet using specific keyword(s). This is a helpful tool for search engine optimization.  </p>
</div>

</div>


<?php

if($_POST){

$qHunt = $_POST['qhunt'];

if(preg_match('/^[a-zA-Z0-9 ]+$/', $qHunt) == 1) {

$length = strlen($qHunt);

$keywords = explode(" ", $qHunt);

$count = 0;
$combineWords = "";

if(count($keywords) > 5 || $length > 50){
$k = 999;
echo "<p style='color:red'>Sorry, you have exceeded the maximum number of keywords or characters! Results may not be relevant to you. </p>";
}else{

for ($i = 0; $i < count($keywords); $i++) 
{
$word = $keywords[$i];
$removeSpace = str_replace(' ','',$word);
$combineWords = $combineWords."+".$removeSpace;
}
}
}else{
$c = 999;
echo "<p style='color:red'>Only letters and numbers are allowed </p>";
}


if($c != 999){
echo "<div class='row'>";

//// Question what
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=what';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Question: What? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";

//// Question why
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=why';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Question: Why? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";


//// Question when
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=when';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card '>";
echo "<div class='card-header'><h5> Question: When? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";


//// Question which
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=which';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Question: Which? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";

//// Question who
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=who';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Question: Who? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";


//// Question where
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=where';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Question: Where? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";

//// Question whose
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=whose';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Question: Whose? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";


//// Question how
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=how';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Question: How? </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";


//// Question best
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=best';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Search: Best </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";


//// Question top
$url_what = 'https://suggestqueries.google.com/complete/search?&output=toolbar&q=top';
$url = $url_what . $combineWords;

$xml = simplexml_load_file($url);
$json = json_encode($xml);
$array = json_decode($json,TRUE);

echo "<div class='col-6 mt-2'>";
echo "<div class='card'>";
echo "<div class='card-header'><h5> Search: Top </h5></div>";
echo "<div class='card-body'>";
echo "<p style='color:black; font-size:15px;'>";

for($i = 0; $i < 10; $i++){
echo $array['CompleteSuggestion'][$i]['suggestion']['@attributes']['data']."</br>";
}

echo "</p>
     </div>
     </div>";

echo "</div>";

echo "</div>";
}

}
?>


<?php
 require "../../template/template_footer_basic.php";
?>



</body>
</html>
