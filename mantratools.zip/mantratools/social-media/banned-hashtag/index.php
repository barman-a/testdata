<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<title>Check Banned Hashtag | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Check Banned Hashtags<h3>
    <h6>Detect and clean banned instagram hashtags<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<?php
if(isset($_POST['hashlist']))
{

$hashlist=$_POST['hashlist'];

}
?>

<div class="row">
<div class=" col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 ">

<form action="" method="post">
<h6>Input hashtags</h6>
<textarea id="hashlist" name="hashlist" placeholder="Hashtags (#fashion #beauty ...)" required class="form-control"  style="width: 100%; resize: none;  height: 120px;" ><?php echo $hashlist; ?></textarea>
<input type='submit' value='Check and Clean' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs mt-2' />
</form>

</div>

<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 ">
<p> There are hundereds of hashtags that are banned from soicial media like Instagram, and one should avoid using those hashtags from your post, contents, and comments. 
This tool detect banned hashtags remove them from a given set of hashtags and geberates clean list.  
 </p>
</div>

</div>


<?php

if($_POST){

$hashList = $_POST['hashlist'];

if(preg_match('/^[a-zA-Z0-9# ]+$/', $hashList) == 1) {

$hashtags = explode(" ", $hashList);

$count = 0;
$bannedList = [];
$cleanList = [];
$bannedList = explode("\n", file_get_contents('../../assets/data/banned_hashtag/master.txt', true));
$b = implode(' ', $bannedList);

if((count($hashtags) > 50) || (strlen($hashList) > 1000)){
echo "Sorry, you are exceeding the maximum limit of hashtags or characters";
}else{
for ($i = 0; $i < count($hashtags); $i++) 
{
$hashi = str_replace('#', '', $hashtags[$i]);
$match = "/".$hashi."/i";
$m = preg_match($match, $b);

if($m == 1){
$count = $count + 1;
}else{
array_push($cleanList,$hashi);
}

}

echo "<table class='table table-borderles wrap'>";
echo "<tr></tr>";

echo "<tr>";
if($count > 0){
echo "<p style='color:red;'> Detected and cleanned ".$count." banned hashtags!</p></br>";
echo "<h5 style='color:blue;'>";
for($i=0; $i < count($cleanList); $i++){
echo "#".$cleanList[$i]." ";
}
}else{
echo "<p style='color:green;'>No banned hashtags detected! All good.</p>";
echo "<h5 style='color:blue;'>";
for($i=0; $i < count($cleanList); $i++){
echo "#".$cleanList[$i]." ";
}
}

echo "</h5>";
echo "</tr>";
echo "</table>";
}

}else{
echo "Unacceptable character found!";
}

}
?>


<?php
 require "../../template/template_footer_basic.php";
?>



</body>
</html>
