text = document.getElementById('listdomain');
text.addEventListener('input', () => {
var v = this.event.target.value;
if(!/[^a-zA-Z0-9-]/.this.event.target.value)) {
this.event.target.style.color = 'red';
document.getElementById("error_list").innerHTML = 'WARNING! text contains unacceptable characters like {}<>;^*';  
document.getElementById("ok_list").innerHTML = '';
} else {
this.event.target.style.color = 'black';
document.getElementById("error_list").innerHTML = '';
document.getElementById("ok_list").innerHTML = 'list - ok!';
}

if (this.event.target.value == ""){
document.getElementById("ok_list").innerHTML = 'Please input domain name list';
}

})
