function waitmsg() {
  var message = document.createElement('div');
  message.innerHTML = '<img src="../../assets/image/wait.gif" width="20" height="20" alt="...."/>';
  var div = document.getElementById('div1');
  div.appendChild(message);
}
