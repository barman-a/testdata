const chkstime = document.querySelectorAll('.chktime');
const chksph = document.querySelectorAll('.chkph');
const selectInput = document.getElementById('sel');


  selectInput.addEventListener('change', () => {
    if (this.event.target.value == 'heatmap') {
	  for (let t of chkstime) {
      t.disabled = false;
	  }
     for (let p of chksph) {
      p.disabled = true;
      p.checked = false;
	  }
    } 
    
    if (this.event.target.value == 'graph') {
	  for (let p of chksph) {
      p.disabled = false;
	  }
    for (let t of chkstime) {
    t.disabled = true;
    t.checked = false;
	  }
    }  

    if (this.event.target.value == 'display_all') {
	  for (let p of chksph) {
    p.disabled = true;
    p.checked = false;
	  }
    for (let t of chkstime) {
    t.disabled = true;
    t.checked = false;
	  }
    }    
});


$('input.chktime').on('change', function() {
    $('input.chktime').not(this).prop('checked', false);  
});

$('input.chkph').on('change', function() {
    $('input.chkph').not(this).prop('checked', false);  
});
