<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<title>Money Making Apps | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Top Money Making Apps in 2021<h3>
    <h6>Make money online using these task based apps<h6>
    </div>";

 require "../../template/template_body_second.php";
?>



<?php

echo "<table class='table' id='table1'>";

echo "<thead>";
echo "<th> Name </th>";
echo "<th> Typical Earning </th>";
echo "<th> Tasks </th>";
echo "<th> Payment Methods </th>";
echo "<th> Get Paid For </th>";
echo "</thead>";

echo "<tbody>";

$count_row = 0;
$csv_file = fopen("../../assets/data/money_making_app/mmapps.csv","r");
while(($get_data = fgetcsv($csv_file, 1000, ",")) !== FALSE) 
{
    $count_row++;	
    $countNum = count($get_data);    
//    echo "$countNum fields in line $count_row:\n";   
    $csv_data[$count_row] = $get_data;
	
}
fclose($csv_file);

// print all data of csv file.
//print_r($csv_data);
//echo $csv_data[1][0]."  ".$csv_data[1][1];

//echo $count_row;


for($i=1; $i <= $count_row; $i++){

echo "<tr>";

echo "<td><img src='../../assets/image/mmapps/".$csv_data[$i][0]."' style='width:12%; height:12%'><a href='".$csv_data[$i][2]."' target='_blank'>  ".$csv_data[$i][1]."</a></td>"; 
echo "<td>".$csv_data[$i][3]."</td>";
echo "<td>".$csv_data[$i][4]."</td>";
echo "<td>".$csv_data[$i][5]."</td>";
echo "<td>".$csv_data[$i][6]."</td>";


echo "</tr>";
}


echo "</tbody>";
echo "</table>";
echo "<div> These amounts are very approximate estimate and vary for individuals. Earning money is hard and needs time, hard work, and dedication. There is no gurantee that you will earn these amount of money using these apps. </div>";


?>


<?php
 require "../../template/template_footer_basic.php";
?>


<script>
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
        searching: false,
	paging: true,
        ordering: true,
        info: true,
        pageLength: 15,
       buttons: []
    } );

} );
</script>


 <script src="../../assets/js/dataTable/jquery.dataTables.min.js"></script>
 <script src="../../assets/js/dataTable/dataTables.buttons.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.flash.min.js"></script>
 <script src="../../assets/js/dataTable/jszip.min.js"></script>
 <script src="../../assets/js/dataTable/pdfmake.min.js"></script>
 <script src="../../assets/js/dataTable/vfs_fonts.js"></script>
 <script src="../../assets/js/dataTable/buttons.html5.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.print.min.js"></script>


</body>
</html>

