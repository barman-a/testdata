<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<script src='../../assets/js/wait.js'></script>";
echo "<title>Bulk Domain Name Search | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Bulk Domain Search<h3>
    <h6>Search multiple domain names and avaliability<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<?php
if(isset($_POST['listdomain']))
{

$s=$_POST['listdomain'];

}
?>

<div class="row">


<div class=" col-xl-3 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 " id="div1">

<form action="" method="post" onsubmit="waitmsg()">
<h6> Domain Names </h6>
<textarea id="listdomain" class="lowercase" name="listdomain" rows="10" placeholder="Enter per line" required  style="width: 100%; resize: none;  height: 30%px;"><?php echo $s; ?></textarea>

</div>

<div class="  col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4  card card-body text-justify m-2 ">

<h6> Select Extension(s) </h6>
<select rows="10" id="listext" name="listext[]" multiple required size="10" style="width: 100%; resize: none;  height: 30%px;">
				<option>Select </option>    
				<option value="com">.com</option>
				<option value="ai">.ai</option>		
				<option value="io">.io</option>
				<option value="me">.me</option>
				<option value="business">.business</option>
				<option value="co.uk">.co.uk</option>
				<option value="co.in">.co.in</option>
				<option value="org">.org</option>		
				<option value="info">.info</option>
				<option value="online">.online</option>
				<option value="shop">.shop</option>

</select>
<input type='submit' value='Search' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs m-2' />
</form>

</div>

<div class=" col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-3 card card-body text-justify m-2 ">
<p> Use this tool to search domain names in bulk. List domain names, select the commonly used extensions (select multiple if required), and search availability. 
 
</p>
</div>

</div>


<?php


if($_POST){
try{
$s=$_POST['listdomain'];
$sLen = strlen($s);

$values = explode("\r\n", $s);

$extensions = $_POST['listext'];
$totalExt = sizeof($extensions);

if(count($values) > 10){
echo "error! exceed max limit of 10 names";
exit;
}elseif($sLen > 200){
echo "error! exceed max character limit";
exit;
}else{
echo "<table class='table' id='table1'>";
echo "<thead>";
echo "<th> Domain Name </th>";
echo "<th> Availablity </th>";
echo "<th> Buy Domain </th>";
echo "</thead>";

echo "<tbody>";


for ($i = 0; $i < count($values); $i++) 
{

for ($j = 0; $j < $totalExt; $j++)
{

$newstr = filter_var($values[$i], FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES);
$newstr = strtolower($newstr);
if(preg_match("/[a-z0-9-]+$/", $newstr) == 1) {

$domain = "www.".$newstr.".".$extensions[$j];

$d = gethostbyname($domain);


echo "<tr>";
if($d != $domain){
echo "<td>".$domain."</td>"; 
echo "<td style='color:red;'><i class='fa fa-circle mr-1' style='color: red'></i> Not available </td>";
echo "<td class='btn-group' role='group'>
      <button class='btn btn-alert btn-md' disabled> Buy </button>
      </td>";
}else{
echo "<td>".$domain."</td>"; 
echo "<td style='color:green;'><i class='fa fa-circle mr-1' style='color: green'></i> Success </td>";
echo "<td class='btn-group' role='group'>
      <a href='https://www.godaddy.com/domainsearch/find?checkAvail=1&domainToCheck=".$domain."' class='btn btn-primary btn-md'> Buy </a>
      </td>";
}
echo "</tr>";
}else{
$count = 1;
}

}

}

echo "</tbody>";
echo "</table>";


} 

if($count == 1){
echo "Sorry, unusual character in domain name detected";
}


}
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}


?>


<?php
 require "../../template/template_footer_basic.php";
?>



<script>
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
        searching: true,
	paging: true,
        ordering: false,
        info: true,
        pageLength: 20,
        buttons: [
            {
                extend: 'csv',
                title: 'domain_name',
		text: 'Export to CSV',
                className: 'btn-secondary' 
            },

        ]
    } );
} );
</script>


 <script src="../../assets/js/dataTable/jquery.dataTables.min.js"></script>
 <script src="../../assets/js/dataTable/dataTables.buttons.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.flash.min.js"></script>
 <script src="../../assets/js/dataTable/jszip.min.js"></script>
 <script src="../../assets/js/dataTable/pdfmake.min.js"></script>
 <script src="../../assets/js/dataTable/vfs_fonts.js"></script>
 <script src="../../assets/js/dataTable/buttons.html5.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.print.min.js"></script>


</body>
</html>
