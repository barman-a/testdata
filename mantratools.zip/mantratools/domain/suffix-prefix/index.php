<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<script src='../../assets/js/wait.js'></script>";
echo "<title>Domain Name Search | ".$home."</title>";


 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Domain Name With Random Suffix/Prefix<h3>
    <h6>Generate random suffix or prefix words for domain search<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<div class="row">
<div class=" col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 " id="div1">

<form action="" method="post" onsubmit="waitmsg()">

<h6> Suffix or Prefix </h6>
<select  class="form-control m-2" name = "sup" required>
<option value = "1" selected>Suffix</option>
<option value = "2">Prefix</option>
</select>

<h6> Suffix/Prefix Word Length</h6>
<select  class="form-control m-2" name = "spl" required>
<option value = "1" selected>Letters</option>
<option value = "2">2-letters-word</option>
<option value = "3">3-letters-word</option>
<option value = "4">4-letters-word</option>
<option value = "5">5-letters-word</option>
<option value = "6">6-letters-word</option>
<option value = "7">7-letters-word</option>
</select>


<?php
if(isset($_POST['word']))
{

$s=$_POST['word'];

}
?>

<h6> Input Word </h6>
<input type="text" name="word" class="form-control m-2" required value="<?php echo $s; ?>"/> 

<h6> Number of Domains </h6>
<select  class="form-control m-2" name = "amt" required>
<option value = "0" selected>Select Number of Names</option>
<option value = "5">5</option>
<option value = "10">10</option>
<option value = "20">20</option>
</select>
<input type='submit' value='Generate Domain Names' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs form-control m-2' id='btn-submit'/>

</form>

</div>

<div class=" col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 " >
<p> Finding a domain name with .com extension has become very difficult, and needs luck to come up with a catchy domain name. 
Use this tool free to generate random and creative domain names with .com extension using choice of word, suffix or prefix, and choice of word length. 
</p>
</div>

</div>



<?php


if($_POST){
try{
$sup=$_POST['sup'];
$words = $_POST['word'];
$total = $_POST['amt'];
$spl_number = $_POST['spl'];

$given_words = [];
$finalWords = [];

$given_words = explode(" ",$words);

$dictionaryFile = "../../assets/data/suffix_prefix/".$spl_number."-letters-words.txt";

//////// Word length 3 //////////////////////
if(strlen($words) > 15){
echo "Character limit exceeded!";
exit;
}


if(preg_match('/^[a-zA-Z0-9- ]+$/', $words)){

$f_word = [];

$f_word = explode("\n", file_get_contents($dictionaryFile, true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$w1 = $f_word[$m];

if($sup == 1){
$w2 = $given_words[0].$w1;
}elseif($sup == 2){
$w2 = $w1.$given_words[0];
}

array_push($finalWords, $w2);

}

echo "<table class='table' id='table1'>";

echo "<thead>";
echo "<th> Domain Name </th>";
echo "<th> Availablity </th>";
echo "<th> Buy Domain </th>";
echo "</thead>";

echo "<tbody>";


///////////////////

for($i=0; $i < $total; $i++){


$domain = "www.".$finalWords[$i].".com";
$d = gethostbyname($domain);

echo "<tr>";

if($d != $domain){
echo "<td>".$domain."</td>"; 
echo "<td style='color:red;'><i class='fa fa-circle mr-1' style='color: red'></i> Not available </td>";
echo "<td class='btn-group' role='group'>
      <button class='btn btn-alert btn-md' disabled> Buy </button>
      </td>";
;
}else{
echo "<td>".$domain."</td>"; 
echo "<td style='color:green;'><i class='fa fa-circle mr-1' style='color: green'></i> Success </td>";
echo "<td class='btn-group' role='group'>
      <a href='https://www.godaddy.com/domainsearch/find?checkAvail=1&domainToCheck=".$domain."' class='btn btn-primary btn-md form-control'> Buy </a>
      </td>";

}

echo "</tr>";
}


echo "</tbody>";
echo "</table>";

}else{
echo "Use only letters, numbers and '-'";
exit;
}



}
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}


?>


<?php
 require "../../template/template_footer_basic.php";
?>

<div class="row">
<div class="col-2"> </div>
<div class="col-8">
<div class="col-6 text-justify"></div>
</div>
<div class="col-2"> </div>




<script>
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
        searching: false,
	paging: true,
        ordering: true,
        info: true,
        pageLength: 20,
       buttons: [
            {
                extend: 'csv',
                title: 'domain_name',
		text: 'Export to CSV',
                className: 'btn-secondary' 
            },

        ]
    } );

} );
</script>


 <script src="../../assets/js/dataTable/jquery.dataTables.min.js"></script>
 <script src="../../assets/js/dataTable/dataTables.buttons.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.flash.min.js"></script>
 <script src="../../assets/js/dataTable/jszip.min.js"></script>
 <script src="../../assets/js/dataTable/pdfmake.min.js"></script>
 <script src="../../assets/js/dataTable/vfs_fonts.js"></script>
 <script src="../../assets/js/dataTable/buttons.html5.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.print.min.js"></script>


</body>
</html>

