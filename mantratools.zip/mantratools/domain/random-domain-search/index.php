<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<script src='../../assets/js/wait.js'></script>";
echo "<title>Random Domain Name Search | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Search Random Domains<h3>
    <h6>Generate random domain names and search avaliability<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<div class="row">

<div class=" col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 " id="div1">

<form action="" method="post" onsubmit="waitmsg()">

<h6> Domain Name Word Length </h6>
<select  class="form-control m-2" name = "wordlen" required>
<option value = "0" selected>Select Length</option>
<option value = "3">3</option>
<option value = "4">4</option>
<option value = "5">5</option>
<option value = "6">6</option>
<option value = "7">7</option>
<option value = "8">8</option>
<option value = "9">9</option>
<option value = "10">10</option>
</select>

<h6> Number of Names </h6>
<select  class="form-control m-2" name = "amt" required>
<option value = "0" selected>Select Number of Names</option>
<option value = "5">5</option>
<option value = "10">10</option>
<option value = "20">20</option>
</select>

<input type='submit' value='Generate Domain Names' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs form-control' id='btn-submit'/>

</form>

</div>

<div class=" col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 " >
<p> This tool generates random words (domain names ) based on the domain name word length and suggests domain names with with .com extension that are still available or for sale. </p>
</div>

</div>



<?php


if($_POST){
try{
$wlen=$_POST['wordlen'];
$total = $_POST['amt'];

$finalWords = [];

//////// Word length 3 //////////////////////

if($wlen == 3){
$f_word = [];
$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$w1 = $f_word[$m];

array_push($finalWords, $w1);

}
}


//////// Word length 4 //////////////////////

if($wlen == 4){

$count = rand(0,1);

if($count == 0){

$f_word = [];
$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($f_word)-1);
$w1 = $f_word[$m];
$w2 = $f_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 1){

$f_word = [];
$l_word = [];
$m_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/1-letters.txt', true));


for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);

$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}

}

//////// Word length 5 //////////////////////

if($wlen == 5){

$count = rand(0,2);

if($count == 0){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 1){

$f_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/5-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$w1 = $f_word[$m];

array_push($finalWords, $w1);

}

}


if($count == 2){

$f_word = [];
$l_word = [];
$m_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));
$m_word = explode("\n", file_get_contents('../../assets/data/random_domain/1-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$p = rand(0,sizeof($m_word)-1);

$w1 = $f_word[$m];
$w2 = $m_word[$p];
$w3 = $l_word[$n];

$w = $w1.$w2.$w3;
array_push($finalWords, $w);


}
}


}

//////// Word length 6 //////////////////////

if($wlen == 6){

$count = rand(0,2);

if($count == 0){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/4-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 1){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($f_word)-1);
$w1 = $f_word[$m];
$w2 = $f_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}

if($count == 2){

$f_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/6-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$w1 = $f_word[$m];

array_push($finalWords, $w1);


}
}

}

//////// Word length 7 //////////////////////

if($wlen == 7){

$count = rand(0,3);

if($count == 0){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/4-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 1){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/5-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}

if($count == 2){

$f_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/7-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$w1 = $f_word[$m];

array_push($finalWords, $w1);


}
}

if($count == 3){

$f_word = [];
$l_word = [];
$m_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));
$m_word = explode("\n", file_get_contents('../../assets/data/random_domain/1-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$p = rand(0,sizeof($m_word)-1);

$w1 = $f_word[$m];
$w2 = $m_word[$p];
$w3 = $l_word[$n];

$w = $w1.$w2.$w3;
array_push($finalWords, $w);


}
}




}

//////// Word length 8 //////////////////////

if($wlen == 8){

$count = rand(0,3);

if($count == 0){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/4-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/4-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 1){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/6-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}

if($count == 2){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/5-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}


if($count == 3){

$f_word = [];
$l_word = [];
$m_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/4-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));
$m_word = explode("\n", file_get_contents('../../assets/data/random_domain/1-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$p = rand(0,sizeof($m_word)-1);

$w1 = $f_word[$m];
$w2 = $m_word[$p];
$w3 = $l_word[$n];

$w = $w1.$w2.$w3;
array_push($finalWords, $w);


}
}



}


//////// Word length 9 //////////////////////

if($wlen == 9){

$count = rand(0,3);

if($count == 0){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/5-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/4-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 1){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/6-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}

if($count == 2){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/7-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/2-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}


if($count == 3){

$f_word = [];
$l_word = [];
$m_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/5-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));
$m_word = explode("\n", file_get_contents('../../assets/data/random_domain/1-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$p = rand(0,sizeof($m_word)-1);

$w1 = $f_word[$m];
$w2 = $m_word[$p];
$w3 = $l_word[$n];

$w = $w1.$w2.$w3;
array_push($finalWords, $w);


}
}


}

//////// Word length 10 //////////////////////

if($wlen == 10){

$count = rand(0,3);

if($count == 0){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/6-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/4-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 1){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/7-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);


}
}

if($count == 2){

$f_word = [];
$l_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/5-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/5-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$w1 = $f_word[$m];
$w2 = $l_word[$n];

$w = $w1.$w2;
array_push($finalWords, $w);

}
}

if($count == 3){

$f_word = [];
$l_word = [];
$m_word = [];

$f_word = explode("\n", file_get_contents('../../assets/data/random_domain/6-letters.txt', true));
$l_word = explode("\n", file_get_contents('../../assets/data/random_domain/3-letters.txt', true));
$m_word = explode("\n", file_get_contents('../../assets/data/random_domain/1-letters.txt', true));

for($i=1; $i <= $total; $i++){
$m = rand(0,sizeof($f_word)-1);
$n = rand(0,sizeof($l_word)-1);
$p = rand(0,sizeof($m_word)-1);

$w1 = $f_word[$m];
$w2 = $m_word[$p];
$w3 = $l_word[$n];

$w = $w1.$w2.$w3;
array_push($finalWords, $w);


}
}




}



///////////////////
echo "<table class='table' id='table1'>";

echo "<thead>";
echo "<th> Domain Name </th>";
echo "<th> Availablity </th>";
echo "<th> Buy Domain </th>";
echo "</thead>";

echo "<tbody>";

for($i=0; $i < $total; $i++){

$domain = "www.".$finalWords[$i].".com";
$d = gethostbyname($domain);

echo "<tr>";

if($d != $domain){
echo "<td>".$domain."</td>"; 
echo "<td style='color:red;'><i class='fa fa-circle mr-1' style='color: red'></i> Not available </td>";
echo "<td class='btn-group' role='group'>
      <button class='btn btn-alert btn-md' disabled> Buy </button>
      </td>";
;
}else{
echo "<td>".$domain."</td>"; 
echo "<td style='color:green;'><i class='fa fa-circle mr-1' style='color: green'></i> Success </td>";
echo "<td class='btn-group' role='group'>
      <a href='https://www.godaddy.com/domainsearch/find?checkAvail=1&domainToCheck=".$domain."' class='btn btn-primary btn-md form-control'> Buy </a>
      </td>";

}

echo "</tr>";
}


echo "</tbody>";
echo "</table>";


}
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}


?>


<?php
 require "../../template/template_footer_basic.php";
?>

<div class="row">
<div class="col-2"> </div>
<div class="col-8">
<div class="col-6 text-justify"></div>
</div>
<div class="col-2"> </div>




<script>
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
        searching: false,
	paging: true,
        ordering: true,
        info: true,
        pageLength: 20,
       buttons: [
            {
                extend: 'csv',
                title: 'domain_name',
		text: 'Export to CSV',
                className: 'btn-secondary' 
            },

        ]
    } );

} );
</script>


 <script src="../../assets/js/dataTable/jquery.dataTables.min.js"></script>
 <script src="../../assets/js/dataTable/dataTables.buttons.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.flash.min.js"></script>
 <script src="../../assets/js/dataTable/jszip.min.js"></script>
 <script src="../../assets/js/dataTable/pdfmake.min.js"></script>
 <script src="../../assets/js/dataTable/vfs_fonts.js"></script>
 <script src="../../assets/js/dataTable/buttons.html5.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.print.min.js"></script>


</body>
</html>

