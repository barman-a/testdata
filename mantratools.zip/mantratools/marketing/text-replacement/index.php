<?php
 require "../../template/template_header.php";

echo "<title>Replace Multiple text</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Replace Multiple Text<h3>
    <h6>Replace keyword with multiple words in a text<h6>
    </div>";

 require "../../template/template_body_second.php";
?>


<?php
if(isset($_POST['replace']) && isset($_POST['replaceText']) && isset($_POST['sub'])){

$find = $_POST['replace'];
$replaceText = $_POST['replaceText'];
$s = nl2br(htmlentities($_POST['sub'], ENT_QUOTES, 'UTF-8'));
}

?>

<table class="table table-borderless">
<form action="" method="post">

<tr>
<td>
<input type="text" id="replace" name="replace" class="form-control" placeholder="Find this in text" required value="<?php echo $find; ?>"/>
<textarea id="replaceText" name="replaceText" placeholder="Replace with this list (input per line)" required class="form-control" style="width: 100%; resize: none;  height: 200px;" ><?php echo $replaceText; ?></textarea>
</br>
<input type='submit' value='Replace Text' class='btn btn-secondary btn-md' />
</td>
<td rowspan='3'>
<textarea id="sub" name="sub" col="100" placeholder="Your text" required class="form-control" style="width: 100%; resize: none;  height: 240px;" ><?php echo strip_tags($s); ?></textarea>
</td>
</tr>

</form>
</table>


<?php

if($_POST){
try{
$find = $_POST['replace'];
$filter_find = preg_match("/^[a-zA-Z0-9 ]+$/", $find);
if($filter_find != 1){
echo "No special character accepted in Find text!";
}
if(strlen($filter_find) > 5 ){
echo "Maximum character in Find in text is 5";
}



$replaceText = $_POST['replaceText'];
$filter_replaceText = preg_match("/^[a-zA-Z0-9\s-]+$/", $replaceText);

if($filter_replaceText == 1){
$values = explode("\r\n", $replaceText);
}else{
echo "No special character accepted!";
}

$s = $_POST['sub'];
$filter_sub = preg_match("/[^{}<>;:&%*]+$/", $s);

if($filter_sub == 1){
$subject = nl2br(htmlentities($_POST['sub'], ENT_QUOTES, 'UTF-8'));
}else{
echo "Unacceptable special character found!";
}

if($filter_find == 1 && $filter_replaceText == 1 && $filter_sub == 1)
{

for ($i = 0; $i < count($values); $i++) 
{

$data = str_replace($find, $values[$i], $subject);

//echo "<button onclick=\"copyToClip(document.getElementById('#txt".$i."').innerText)\" class='btn btn-primary btn-md'>Copy ".$values[$i]."</button>";
echo "<button id=\"button1\" onclick=\"CopyToClipboard('txt".$i."')\">Click to copy</button>";
echo "<div class='card_txtreplace' id='txt".$i."'>".$data."</div>";
echo "</br>";
//echo "<button onclick=\"copyToClipboard('#txt".$i."')\" class='btn btn-primary btn-md'>Copy".$values[$i]."</button>";
if($i == 2){
echo "<div> </div>";
}
}

}

}
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}


?>


<?php
 require "../../template/template_footer_basic.php";
?>


<script>
function CopyToClipboard(containerid) {
  if (document.selection) {
    var range = document.body.createTextRange();
    range.moveToElementText(document.getElementById(containerid));
    range.select().createTextRange();
    document.execCommand("copy");
  } else if (window.getSelection) {
    var range = document.createRange();
    range.selectNode(document.getElementById(containerid));
    window.getSelection().addRange(range);
    document.execCommand("copy");
    alert("Text has been copied")
  }
}</script>



</body>
</html>
