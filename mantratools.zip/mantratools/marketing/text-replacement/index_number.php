<!DOCTYPE HTML>
<html>
<head>

  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>  
  <link rel="stylesheet" type= "text/css" href = "../css/dataTable/jquery.dataTables.min.css" />
  <link rel="stylesheet" type= "text/css" href = "../css/dataTable/buttons.dataTables.min.css" />


</head>

  <body>
<div class="row">

<div class="col-md-3"> </div>

<div class="col-6">
<form action="" method="post">
<table class="table table-borderless">
<tr>
<td>
<input type="text" id="replace" name="replace" placeholder="Replace this text with number" required></textarea>
</td>
<td>
<select  class="form-control" name = "amt" required>
<option value = "0" selected>Select </option>
<option value = "10">1 - 10</option>
<option value = "100">1 - 100</option>
<option value = "1000">1 - 1000</option>
<option value = "2000">1- 2000</option>
</select>
</td>
<td>
<input type='submit' value='Generate' class='btn btn-primary btn-md form-control' />
</td>
</tr>
</table>
<textarea id="sub" name="sub" col="100" placeholder="Your text" required class="form-control"></textarea>

</form>


</div>

<div class="col-md-3"> </div>

</div>

<div class="row">
<div class="col-md-3"> </div>
<div class="col-6">

<?php

if($_POST){
try{
$find = $_POST['replace'];
$total = $_POST['amt'];

$subject = nl2br(htmlentities($_POST['sub'], ENT_QUOTES, 'UTF-8'));

for ($i = 1; $i <= $total; $i++) 
{

$data = str_replace($find, $i, $subject);

echo $data;
echo "</br>";


}


}
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}


?>


</body>
</html>
