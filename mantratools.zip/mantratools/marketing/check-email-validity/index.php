<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<title>Email Verifier | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Email Verification<h3>
    <h6>Check validity of an email based on domain name and disposable address</h6>
    </div>";

 require "../../template/template_body_second.php";
?>


<?php
if(isset($_POST['email']))
{

$em=$_POST['email'];

}
?>


<div class="row">
<div class=" col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 ">

<form action="" method="post" id="formTosubmit">
<div><h6>Enter a email address</h6></div>
<div class="input-group mb-3">
  <input type="email" id="email" name="email" placeholder="Email" required class="form-control" value="<?php echo $em; ?>" />
  <div class="input-group-append">
  <input type='submit' value='Chek email' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs'/>
</div>
</div>
</form>


</div>

<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 ">
<p> Email verification tool scan your email and check domain availability and disposability of the email address. This tool identifies the risk of an email and results in higher deliverability.</p>
</div>

</div>






<?php

if($_POST){

echo "<div class='row'>";
echo "<div class='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2'>";

$em=$_POST['email'];

if(preg_match('/^[a-zA-Z0-9-_.@]+$/', $em) == 1 && strlen($em) < 100) {

//$em="aaa@dodgit.com";

function domain_exists($email, $record = 'MX'){
	list($user, $domain) = explode('@', $email);
	return checkdnsrr($domain, $record);
}

if(domain_exists($em)) {
$domain_exist = "True";
}else {
$domain_exist = "False";
}

$count = 0;
$ll = explode('@', $em);
$search = $ll[1];
$emailFirstPart = $ll[0];

if(strlen($emailFirstPart) <= 64){

$search = preg_replace('/=.*/', '', $search);

$dis_name = [];
$dis_name = explode("\n", file_get_contents('../../assets/data/email_check/disposableemail_unq.txt', true));
//$dis_name = explode("\n", file_get_contents('./test.txt', true));


for($i=0; $i < count($dis_name); $i++){
//echo $dis_name[$i]."  ".$search."  ".strlen($dis_name[$i])."  ".strlen($search)."</br>";
if($dis_name[$i] == $search) {
 $count = $count + 1;
}
}

if($count > 0){
$disposible = "True";
}else{
$disposible = "False";
}

echo "Domain Exists: ". $domain_exist."</br>";
echo "Disposible: ". $disposible."</br>";

if($domain_exist == "True" && $disposible == "False"){

echo "<div class='alert alert-success' role='alert'>
<i class='fa fa-check-circle-o' aria-hidden='true'></i>  This is a valid email 
</div>";

}elseif($domain_exist == "True" && $disposible == "True"){

echo "<div class='alert alert-danger' role='alert'>
<i class='fa fa-check-circle-o' aria-hidden='true'></i>  This is a disposible email 
</div>";

}elseif($domain_exist == "False" && $disposible == "True"){

echo "<div class='alert alert-danger' role='alert'>
<i class='fa fa-check-circle-o' aria-hidden='true'></i>  This is a not a valid email 
</div>";

}elseif($domain_exist == "False" && $disposible == "False"){

echo "<div class='alert alert-danger' role='alert'>
<i class='fa fa-check-circle-o' aria-hidden='true'></i>  This is a not a valid email 
</div>";

}

}else{

echo "Not a valid email! Please check";
}

}else{
echo "Invalid email address! Please check";
}
echo "</div>";
echo "</div>";
}

?>

<?php
 require "../../template/template_footer_basic.php";
?>


</body>
</html>
