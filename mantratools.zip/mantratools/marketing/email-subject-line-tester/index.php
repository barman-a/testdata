<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<title>Email Subject Line Tester | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Email Subject Line Tester<h3>
    <h6>Identify spam trigerring keywords in email subject line<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<?php
if(isset($_POST['emailSub']))
{

$emsub=$_POST['emailSub'];

}
?>

<div class="row">
<div class=" col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 ">

<form action="" method="post">
<h6>Input email subject</h6>
<div class="input-group mb-3">
<input type='text' id="emailSub" name="emailSub" placeholder="Subject line of email" required class="form-control" value="<?php echo $emsub; ?>" />
<div class="input-group-append">
<input type='submit' value='Check!' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs' />
</div>
</div>

</form>

</div>

<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 ">
<p> Sending emails for marketing is not easy and most of the time the subject line of the email determines whether the email ends up in subscriber's spam folder or not.
This tool scan the subject line for spam trigerring keywords or elements and alerts about the severity of the content.    
 </p>
</div>

</div>


<?php

if($_POST){

$esub = $_POST['emailSub'];
$esub = strtolower($esub);

$emailSubWords = explode(" ", $esub);
$actualWordCount = str_word_count($esub);
$emailSubWordCount = count($emailSubWords);
$emailSubWordLen = strlen($esub);

$esub = str_replace(" ","",$esub);

if(preg_match('/^[A-Za-z0-9_~\-!@#,:?\[\]\$%\&\(\)]+$/', $esub) == 1) {

$count = 0;
$bannedList = [];
$cleanList = [];
$bannedList = explode("\n", file_get_contents('../../assets/data/email_subject_line/sorted_unq.dat', true));

$b = implode('\r\n', $bannedList);

if($emailSubWordCount > 20 || $emailSubWordLen > 200){
echo "Sorry, you are exceeding the limit - subject line is too large!";
}else{
for ($i = 0; $i < count($bannedList); $i++) 
{
$b = strtolower($bannedList[$i]);
$b = str_replace(" ","",$b);

//$pattern = "'(".$b.")'";
$pattern = "/".$b."/i";
$m = preg_match_all($pattern, $esub);
//echo $pattern."   ".$esub."   ".$m."</br>";

if($m == 1){
$count = $count + 1;
}

}

echo "<div class='row'>";
echo "<div class='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2'>";

if($count > 0){
echo "<div class='alert alert-warning' role='warning'>Number of words: ".$actualWordCount."   [6-8 words are ideal] </div>";

echo "<div class='alert alert-warning' role='warning'>Number of characters: ".$emailSubWordLen."   [50-70 characters are ideal] </div>";

echo "<div class='alert alert-danger' role='alert'>
<i class='fa fa-exclamation-circle' aria-hidden='true'></i>  Contains spam trigerring elements! 
</div>";

}else{
echo "<div class='alert alert-warning' role='warning'>Number of words: ".$actualWordCount."   [6-15 words are ideal] </div>";

echo "<div class='alert alert-warning' role='warning'>Number of characters: ".$emailSubWordLen."   [60-120 characters are ideal]</div>";

echo "<div class='alert alert-success' role='success'>
<i class='fa fa-check-circle-o' aria-hidden='true'></i>  Looks OK! Good to go. 
</div>";

}

echo "</div>";

}

}else{
echo "Subject line contains inappropriate character(s)!";
}

echo "</div>";

}
?>


<?php
 require "../../template/template_footer_basic.php";
?>



</body>
</html>
