
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="../../index.html">
   <img src="../../assets/image/logo.png" width="60" height="45" alt="">  MantraTools</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="../../index.html"><i class="fa fa-home fa-fw mr-1"></i>Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <i class="fa fa-cog fa-fw mr-1"></i>Domain
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../../domain/random-domain-search/">Random Domain Search</a>
          <a class="dropdown-item" href="../../domain/multi-domain-search/">Multi Domain Search</a>
          <a class="dropdown-item" href="../../domain/suffix-prefix/">Domain Search with Suffix/Prefix</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <i class="fa fa-line-chart fa-fw mr-1"></i>Marketing
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../../marketing/check-email-validity">Email Validity</a>
          <a class="dropdown-item" href="../../marketing/email-subject-line-tester">Email Subject Check</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <i class="fa fa-commenting-o fa-fw mr-1"></i>Social Media
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../../social-media/banned-hashtag">Banned Hashtag</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <i class="fa fa-search fa-fw mr-1"></i>Seo
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../../seo/question-hunter/">Question Hunter</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-book fa-fw mr-1"></i>Resource
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../../resource/money-making-apps">Money Making Apps</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         <i class="fa fa-puzzle-piece fa-fw mr-1"></i>Misc.
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../../misc/digital-signature">Generate Signature</a>
          <a class="dropdown-item" href="../../misc/random-name-generator">Random Names</a>
          <a class="dropdown-item" href="../../misc/euromillion-number-generator">Euromillion</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-question-circle fa-fw mr-1"></i>Help
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../../help/privacy-policy">Privacy Policy</a>
          <a class="dropdown-item" href="../../help/terms-and-condictions">Terms and Condictions</a>
          <a class="dropdown-item" href="../../help/contact">Contact</a>
        </div>
      </li>
    </ul>
  </div>
</nav>


<div class="container-fluid">
    <div class="row">
    <div class="col-2"></div>

