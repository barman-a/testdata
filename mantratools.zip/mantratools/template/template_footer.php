</div>
        <div class="col-2">
            <p>Advertisement</p>
        </div>


    </div>
</div>


<div class="footer">
  <div class="row">
   <div class="col-4">

	<div class="text-light text-center">
	 <a class="text-light" href="contctus.php"><p class="d-inline lead">Contact Us</p></a><br>
	 <p class="d-inline lead">Disclaimer</p><br>
	 </p>
	</div>

   </div>
   <div class="col-4">

	<div class="text-light text-center">
	 <h5 class="card-title text-white display-4" style="font-size:20px">Social Media</h5>
         <a class="text-light" href="https://www.facebook.com"><i class="fa fa-facebook-square fa-fw fa-2x"></i></a>
	 <a class="text-light" href="#"><i class="fa fa-twitter-square fa-fw fa-2x"></i></a>
         <a class="text-light" href="#"><i class="fa fa-instagram fa-fw fa-2x"></i></a>
         <a class="text-light" href="#"><i class="fa fa-linkedin fa-fw fa-2x"></i></a>
	 </p>
	</div>

   </div>

 </div>
</div>