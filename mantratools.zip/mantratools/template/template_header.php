<!DOCTYPE html>
<html lang="en">
<head>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>


  <link rel="stylesheet" href="../../assets/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../../assets/fa-4.7/css/font-awesome.min.css">

  <link rel="stylesheet" type= "text/css" href = "../../assets/css/dataTable/jquery.dataTables.min.css" />
  <link rel="stylesheet" type= "text/css" href = "../../assets/css/dataTable/buttons.dataTables.min.css" />

  <link rel="stylesheet" type= "text/css" href = "../../assets/css/default.css" />
  <link rel="stylesheet" type= "text/css" href = "../../assets/css/modal-msg.css" />
  <link rel="stylesheet" type= "text/css" href = "../../assets/css/card.css" />

<?php

 $home = "MantraTools"; 

?>
