<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<title>Random Name Generator | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Random Name Generator<h3>
    <h6>Generate random names for your development project<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<div class="row">
<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 ">

<form action="" method="post">
<h6> Select Sex</h6>
<select  class="form-control m-2" name = "sex" required>
<option value = "" selected>Select</option>
<option value = "male">Male</option>
<option value = "female">Female</option>
<option value = "both">Both</option>
</select>
<input type='submit' value='Generate 100 Random Names' class='btn btn-secondary btn-lg btn-md btn-sm btn-xs form-control m-2' />
</form>
</div>

<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 ">
<p> Random name generator generates names randomly along with email, age, sex, and id. This tool is helpful for generating mock data for project development </p>
</div>

</div>


<?php
if($_POST){

echo "<table class='table display nowrap'  id='table1'>";
echo "<thead>";
echo "<tr>";
echo "<th>First Name</th>";
echo "<th>Last Name</th>";
echo "<th>Email</th>";
echo "<th>Age</th>";
echo "<th>Sex</th>";
echo "<th>ID Number</th>";
echo "</tr>";
echo "</thead>";

echo "<tbody>";


try{
$s=$_POST['sex'];

if($s == 'male'){

$f_name = [];
$l_name = [];

$firstName = [];
$lastName = [];

$f_name = explode("\n", file_get_contents('../../assets/data/random_names/first_names_male.txt', true));
$l_name = explode("\n", file_get_contents('../../assets/data/random_names/last_names.txt', true));

for($i=1; $i <= 100; $i++){
$n = rand(1,2113);
$m = rand(1,7412);
array_push($firstName, $f_name[$n]);
array_push($lastName, $l_name[$m]);
}

for($i=0; $i < 100; $i++){
$str = $firstName[$i].".".$lastName[$i];
$str = strtolower($str);
$u1 = rand(100,999);
$u2 = rand(1000,9999);
$uid = "C".$u1.$u2;


echo "<tr>";
echo "<td>".$firstName[$i]."</td>";
echo "<td>".$lastName[$i]."</td>";
echo "<td>".$str."@example.com </td>";
echo "<td>".rand(22,62)."</td>";
echo "<td>Male</td>";
echo "<td>".$uid."</td>";
echo "</tr>";

}

}

if($s == 'female'){

$f_name = [];
$l_name = [];

$firstName = [];
$lastName = [];

$f_name = explode("\n", file_get_contents('../../assets/data/random_names/first_names_female.txt', true));
$l_name = explode("\n", file_get_contents('../../assets/data/random_names/last_names.txt', true));

for($i=1; $i <= 100; $i++){
$n = rand(1,1041);
$m = rand(1,7412);
array_push($firstName, $f_name[$n]);
array_push($lastName, $l_name[$m]);
}

for($i=0; $i < 100; $i++){
$str = $firstName[$i].".".$lastName[$i];
$str = strtolower($str);
$u1 = rand(100,999);
$u2 = rand(1000,9999);
$uid = "C".$u1.$u2;

echo "<tr>";
echo "<td>".$firstName[$i]."</td>";
echo "<td>".$lastName[$i]."</td>";
echo "<td>".$str."@example.com </td>";
echo "<td>".rand(22,62)."</td>";
echo "<td>Female</td>";
echo "<td>".$uid."</td>";
echo "</tr>";

}

}



if($s == 'both'){

$f_name = [];
$l_name = [];

$firstName = [];
$lastName = [];

$f_name = explode("\n", file_get_contents('../../assets/data/random_names/first_names_male.txt', true));
$l_name = explode("\n", file_get_contents('../../assets/data/random_names/last_names.txt', true));

for($i=1; $i <= 50; $i++){
$n = rand(1,2113);
$m = rand(1,7412);
array_push($firstName, $f_name[$n]);
array_push($lastName, $l_name[$m]);
}

for($i=0; $i < 50; $i++){
$str = $firstName[$i].".".$lastName[$i];
$str = strtolower($str);
$u1 = rand(100,999);
$u2 = rand(1000,9999);
$uid = "C".$u1.$u2;


echo "<tr>";
echo "<td>".$firstName[$i]."</td>";
echo "<td>".$lastName[$i]."</td>";
echo "<td>".$str."@example.com </td>";
echo "<td>".rand(22,62)."</td>";
echo "<td>Male</td>";
echo "<td>".$uid."</td>";
echo "</tr>";

}

$f_name = [];
$l_name = [];

$firstName = [];
$lastName = [];

$f_name = explode("\n", file_get_contents('../../assets/data/random_names/first_names_female.txt', true));
$l_name = explode("\n", file_get_contents('../../assets/data/random_names/last_names.txt', true));

for($i=1; $i <= 50; $i++){
$n = rand(1,1041);
$m = rand(1,7412);
array_push($firstName, $f_name[$n]);
array_push($lastName, $l_name[$m]);
}

for($i=0; $i < 50; $i++){
$str = $firstName[$i].".".$lastName[$i];
$str = strtolower($str);
$u1 = rand(100,999);
$u2 = rand(1000,9999);
$uid = "C".$u1.$u2;

echo "<tr>";
echo "<td>".$firstName[$i]."</td>";
echo "<td>".$lastName[$i]."</td>";
echo "<td>".$str."@example.com </td>";
echo "<td>".rand(22,62)."</td>";
echo "<td>Female</td>";
echo "<td>".$uid."</td>";
echo "</tr>";

}

}

}
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}

echo "</tbody>";
echo "</table>";

?>


<?php
 require "../../template/template_footer_basic.php";
?>

<script>
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
        searching: true,
	paging: true,
        ordering: true,
        info: true,
        pageLength: 20,
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'Random_Names',
		text: 'Export to Excel'
            },
        ]
    } );
} );
</script>


 <script src="../../assets/js/dataTable/jquery.dataTables.min.js"></script>
 <script src="../../assets/js/dataTable/dataTables.buttons.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.flash.min.js"></script>
 <script src="../../assets/js/dataTable/jszip.min.js"></script>
 <script src="../../assets/js/dataTable/pdfmake.min.js"></script>
 <script src="../../assets/js/dataTable/vfs_fonts.js"></script>
 <script src="../../assets/js/dataTable/buttons.html5.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.print.min.js"></script>



</body>
</html>
