<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<title>Generate Digital Signature | ".$home."</title>";


?>

 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Monsieur+La+Doulaise">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Arizonia">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rouge+Script">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alex+Brush">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sail">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allura">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amita">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Grey+Qo">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sacramento">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Homemade+Apple">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Qwigley">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ballet">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Miss+Fajardose">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Dawning+of+a+New+Day">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Euphoria+Script">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ephesis">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Italianno">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Birthstone+Bounce">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Fleur+De+Leah">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Carattere">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Parisienne">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cherish">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pinyon+Script">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Niconne">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Calligraffitti">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=MonteCarlo">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ruthie">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Butterfly+Kids">
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Princess+Sofia">


 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="../../assets/js/html2canvas.min.js"></script>
 <script src="../../assets/js/html2canvas.js"></script>


 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>  
  <link rel = "stylesheet" type = "text/css" href = "../../assets/css/fonts.css" />

<?php
 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Digital Signature<h3>
    <h6>Generate signature using google fonts<h6>
    </div>";

 require "../../template/template_body_second.php";
?>

<div class="row">
<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2">

<div><h6>Enter your name</h6></div>
<div class="input-group mb-3">
  <input type="text" id="myText" name="myText" placeholder="Full name" required class="form-control" style='width:40%;' aria-describedby="basic-addon2" maxlength="50" pattern="[a-zA-Z ]{1,30}"/>
  <div class="input-group-append">
  <button onclick = "submitTxt()" id="btn" class='btn btn-secondary btn-lg btn-md btn-sm btn-xs ' > Generate Signature </button>
  </div>
</div>
</div>

<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2">
<p> Signature generator uses 30 awesome google fonts to generate digital signature. Generated signature images can be downloaded (using right click) or can be copy and pasted.</p>
</div>

</div>

 <div class="row">

  <div class="col-6">
  <center>
  <div class="tangerine" id="txtDiv1" style="display: none; padding: 25px; border:thin;"></div>
  <div class="monsieur" id="txtDiv2" style="display: none; padding: 25px; border:thin;"></div>
  <div class="arizonia" id="txtDiv3" style="display: none; padding: 25px; border:thin;"></div>
  <div class="rougescript" id="txtDiv4" style="display: none; padding: 25px; border:thin;"></div>
  <div class="alexbrush" id="txtDiv5" style="display: none; padding: 25px; border:thin;"></div>
  <div class="sail" id="txtDiv6" style="display: none; padding: 25px; border:thin;"></div>
  <div class="allura" id="txtDiv7" style="display: none; padding: 25px; border:thin;"></div>
  <div class="amita" id="txtDiv8" style="display: none; padding: 25px; border:thin;"></div>
  <div class="greyqo" id="txtDiv9" style="display: none; padding: 25px; border:thin;"></div>
  <div class="sacramento" id="txtDiv10" style="display: none; padding: 25px; border:thin;"></div>
  <div class="homemade" id="txtDiv11" style="display: none; padding: 25px; border:thin;"></div>
  <div class="qwigley" id="txtDiv12" style="display: none; padding: 25px; border:thin;"></div>
  <div class="ballet" id="txtDiv13" style="display: none; padding: 25px; border:thin;"></div>
  <div class="missfajardose" id="txtDiv14" style="display: none; padding: 25px; border:thin;"></div>
  <div class="drawing" id="txtDiv15" style="display: none; padding: 25px; border:thin;"></div>
  <div class="euphoriascript" id="txtDiv16" style="display: none; padding: 25px; border:thin;"></div>
  <div class="ephesis" id="txtDiv17" style="display: none; padding: 25px; border:thin;"></div>
  <div class="italianno" id="txtDiv18" style="display: none; padding: 25px; border:thin;"></div>
  <div class="birthstonebounce" id="txtDiv19" style="display: none; padding: 25px; border:thin;"></div>
  <div class="fleur" id="txtDiv20" style="display: none; padding: 25px; border:thin;"></div>
  <div class="carattere" id="txtDiv21" style="display: none; padding: 25px; border:thin;"></div>
  <div class="parisienne" id="txtDiv22" style="display: none; padding: 25px; border:thin;"></div>
  <div class="cheris" id="txtDiv23" style="display: none; padding: 25px; border:thin;"></div>
  <div class="pinvon" id="txtDiv24" style="display: none; padding: 25px; border:thin;"></div>
  <div class="niconne" id="txtDiv25" style="display: none; padding: 25px; border:thin;"></div>
  <div class="calligraffitti" id="txtDiv26" style="display: none; padding: 25px; border:thin;"></div>
  <div class="montecarlo" id="txtDiv27" style="display: none; padding: 25px; border:thin;"></div>
  <div class="ruthie" id="txtDiv28" style="display: none; padding: 25px; border:thin;"></div>
  <div class="buuterflykids" id="txtDiv29" style="display: none; padding: 25px; border:thin;"></div>
  <div class="princesssofia" id="txtDiv30" style="display: none; padding: 25px; border:thin;"></div>

  </center>
 </div>
 </div>


<?php
 require "../../template/template_footer_basic.php";
?>


<script>
$("#btn").click(function(){

$('#txtDiv1').show()
let el1 = document.querySelector("#txtDiv1")
html2canvas(el1,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas) 
})


$('#txtDiv2').show()
let el2 = document.querySelector("#txtDiv2")
html2canvas(el2,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv3').show()
let el3 = document.querySelector("#txtDiv3")
html2canvas(el3,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv4').show()
let el4 = document.querySelector("#txtDiv4")
html2canvas(el4,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv5').show()
let el5 = document.querySelector("#txtDiv5")
html2canvas(el5,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv6').show()
let el6 = document.querySelector("#txtDiv6")
html2canvas(el6,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv7').show()
let el7 = document.querySelector("#txtDiv7")
html2canvas(el7,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv8').show()
let el8 = document.querySelector("#txtDiv8")
html2canvas(el8,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv9').show()
let el9 = document.querySelector("#txtDiv9")
html2canvas(el9,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv10').show()
let el10 = document.querySelector("#txtDiv10")
html2canvas(el10,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv11').show()
let el11 = document.querySelector("#txtDiv11")
html2canvas(el11,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv12').show()
let el12 = document.querySelector("#txtDiv12")
html2canvas(el12,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv13').show()
let el13 = document.querySelector("#txtDiv13")
html2canvas(el13,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv14').show()
let el14 = document.querySelector("#txtDiv14")
html2canvas(el14,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv15').show()
let el15 = document.querySelector("#txtDiv15")
html2canvas(el15,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv16').show()
let el16 = document.querySelector("#txtDiv16")
html2canvas(el16,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})


$('#txtDiv17').show()
let el17 = document.querySelector("#txtDiv17")
html2canvas(el17,{backgroundColor:null}).then(canvas => {
  document.body.appendChild(canvas)  
})

$('#txtDiv18').show()
let el18 = document.querySelector("#txtDiv18")
html2canvas(el18,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv19').show()
let el19 = document.querySelector("#txtDiv19")
html2canvas(el19,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv20').show()
let el20 = document.querySelector("#txtDiv20")
html2canvas(el20,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv21').show()
let el21 = document.querySelector("#txtDiv21")
html2canvas(el21,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv22').show()
let el22 = document.querySelector("#txtDiv22")
html2canvas(el22,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv23').show()
let el23 = document.querySelector("#txtDiv23")
html2canvas(el23,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv24').show()
let el24 = document.querySelector("#txtDiv24")
html2canvas(el24,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv25').show()
let el25 = document.querySelector("#txtDiv25")
html2canvas(el25,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv26').show()
let el26 = document.querySelector("#txtDiv26")
html2canvas(el26,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv27').show()
let el27 = document.querySelector("#txtDiv27")
html2canvas(el27,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv28').show()
let el28 = document.querySelector("#txtDiv28")
html2canvas(el28,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv29').show()
let el29 = document.querySelector("#txtDiv29")
html2canvas(el29,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv30').show()
let el30 = document.querySelector("#txtDiv30")
html2canvas(el30,{backgroundColor:null}).then(canvas => {
document.body.appendChild(canvas)
})

$('#txtDiv1').hide()
$('#txtDiv2').hide()
$('#txtDiv3').hide()
$('#txtDiv4').hide()
$('#txtDiv5').hide()
$('#txtDiv6').hide()
$('#txtDiv7').hide()
$('#txtDiv8').hide()
$('#txtDiv9').hide()
$('#txtDiv10').hide()
$('#txtDiv11').hide()
$('#txtDiv12').hide()
$('#txtDiv13').hide()
$('#txtDiv14').hide()
$('#txtDiv15').hide()
$('#txtDiv16').hide()
$('#txtDiv17').hide()
$('#txtDiv18').hide()
$('#txtDiv19').hide()
$('#txtDiv20').hide()
$('#txtDiv21').hide()
$('#txtDiv22').hide()
$('#txtDiv23').hide()
$('#txtDiv24').hide()
$('#txtDiv25').hide()
$('#txtDiv26').hide()
$('#txtDiv27').hide()
$('#txtDiv28').hide()
$('#txtDiv29').hide()
$('#txtDiv30').hide()

})

function submitTxt() {
  $("#txtDiv1").text($("#myText").val());
  $("#txtDiv2").text($("#myText").val());
  $("#txtDiv3").text($("#myText").val());
  $("#txtDiv4").text($("#myText").val());
  $("#txtDiv5").text($("#myText").val());
  $("#txtDiv6").text($("#myText").val());
  $("#txtDiv7").text($("#myText").val());
  $("#txtDiv8").text($("#myText").val());
  $("#txtDiv9").text($("#myText").val());
  $("#txtDiv10").text($("#myText").val());
  $("#txtDiv11").text($("#myText").val());
  $("#txtDiv12").text($("#myText").val());
  $("#txtDiv13").text($("#myText").val());
  $("#txtDiv14").text($("#myText").val());
  $("#txtDiv15").text($("#myText").val());
  $("#txtDiv16").text($("#myText").val());
  $("#txtDiv17").text($("#myText").val());
  $("#txtDiv18").text($("#myText").val());
  $("#txtDiv19").text($("#myText").val());
  $("#txtDiv20").text($("#myText").val());
  $("#txtDiv21").text($("#myText").val());
  $("#txtDiv22").text($("#myText").val());
  $("#txtDiv23").text($("#myText").val());
  $("#txtDiv24").text($("#myText").val());
  $("#txtDiv25").text($("#myText").val());
  $("#txtDiv26").text($("#myText").val());
  $("#txtDiv27").text($("#myText").val());
  $("#txtDiv28").text($("#myText").val());
  $("#txtDiv29").text($("#myText").val());
  $("#txtDiv30").text($("#myText").val())
}

</script>  
</center>
</div>
</body>
</html>