<?php
error_reporting (E_ALL ^ E_NOTICE);
 require "../../template/template_header.php";

echo "<title>Euromillion Number Generator | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
    <h3>Euromillion Number Generator<h3>
    <h6>Generate lucky numbers based on your birthday and game day<h6>
    </div>";

 require "../../template/template_body_second.php";
?>



<div class="row">
<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 ">
<form action="" method="post">
<h6> Select Your Birthday</h6>
<input type="date" name="bday" placeholder="Date" class="form-control m-2 " data-date="" data-date-format="DD MMMM YYYY" value=""/>
<h6>Select Game Date</h6>
<input type="date" name="gday" placeholder="Date" class="form-control m-2 " data-date="" data-date-format="DD MMMM YYYY" value=""/>
<input type='submit' value='Generate Lucky Numbers' class='btn btn-secondary btn-lg btn-md btn-sm btn-xs form-control m-2' />
</form>
</div>

<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 card card-body text-justify m-2 ">
<p> Playing lottery needs luck, and our luck is determined on the day when we were born. This euromillion number generator takes into account of your birthday and date of the game day to generate 5 sets of lucky numbers. There
is no gurantee that these numbers will bring you fortune, but if you win any please let us know. 
 </p>
</div>

</div>



<?php
if($_POST){

function gen_num($xMin,$xMax,$d)
{
   $numbers = [];

   for ($i=1; $i <=5; $i++)
   {

   $n = round((rand($xMin,$xMax)/$d),0);

   $arrlength = count($numbers);
   for($x = 0; $x < $arrlength; $x++) 
   {
   if($numbers[$x] == $n)
   {
   while(true)
   {
   $n = round((rand($xMin,$xMax)/$d),0);
   if($numbers[$x] != $n){
   break;
   }
   }
   }
   }

   if($n == 0){
   $n = 1;
   }
   if($n > 50){
   $n = 50;
   }

   array_push($numbers,$n);

   }
   sort($numbers);
   return $numbers;

}


function gen_num_ls($xMin,$yMax,$d)
{
   $numbersls = [];

   for ($i=1; $i <=2; $i++)
   {

   $n = round((rand($xMin,$yMax)/$d),0);

   $arrlength = count($numbersls);
   for($x = 0; $x < $arrlength; $x++) 
   {
   if($numbersls[$x] == $n)
   {
   while(true)
   {
   $n = round((rand($xMin,$xMax)/$d),0);
   if($numbersls[$x] != $n){
   break;
   }
   }
   }
   }

   if($n == 0){
   $n = 1;
   }
   if($n > 12){
   $n = 12;
   }

   array_push($numbersls,$n);
   }

   sort($numbersls);
   return $numbersls;

}


try{
$bd=$_POST['bday'];
$gd=$_POST['gday'];

$days = ((strtotime($gd) - strtotime($bd))/60/60/24) + 1;
$years = round($days/365,0);
$months = round($years * 12,0);
$sumall = $days + $years + $months;
$diff = $days - $years - $months;


$today = date("Y-m-d");

if(strtotime($gd) < strtotime($bd)){
echo "Game day must be greater than the birthday";
}elseif($bd == "" || $gd == ""){
echo "Please select dates";
}elseif($years < 18){
echo "You must be 18 to play lottery";
}elseif($gd < $today){
echo "Sorry, you can not play a past game!";
}else{

echo "<div class='row'>";
echo "<div class='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2'>";

echo "<table class='table display nowrap table-borderless table-responsive'  id='table3'>";
echo "<thead>";
echo "<tr>";
echo "<th>1st</th>";
echo "<th>2nd</th>";
echo "<th>3rd</th>";
echo "<th>4th</th>";
echo "<th>5th</th>";
echo "<th class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-star fa-stack-2x' style='color:#FFC300;'></i>";
echo "</span>";
echo "</th>";
echo "<th class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-star fa-stack-2x' style='color:#FFC300;'></i>";
echo "</span>";
echo "</th>";

echo "</tr>";
echo "</thead>";

echo "<tbody>";

$dayMin = 1 * $days;
$dayMax = 50 * $days;
$dayLSMax = 12 * $days;

$genNum = [];
$genNumLS = [];
$genNum = gen_num($dayMin, $dayMax, $days);
$genNumLS = gen_num_ls($dayMin, $dayLSMax, $days);

echo "<tr>";

$arrlength = count($genNum);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#DDDDDD;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNum[$x]."</strong></i>";
echo "</span>";
echo "</td>";


}

$arrlength = count($genNumLS);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#FFF4A4  ;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNumLS[$x]."</strong></i>";
echo "</span>";
echo "</td>";

}


echo "</tr>";


//////////////////////////////////////////////

$monthMin = 1 * $months;
$monthMax = 50 * $months;
$monthLSMax = 12 * $months;

$genNum2 = [];
$genNumLS2 = [];
$genNum2 = gen_num($monthMin, $monthMax, $months);
$genNumLS2 = gen_num_ls($monthMin, $monthLSMax, $months);

echo "<tr>";

$arrlength = count($genNum2);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#DDDDDD;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNum2[$x]."</strong></i>";
echo "</span>";
echo "</td>";


}

$arrlength = count($genNumLS2);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#FFF4A4 ;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNumLS2[$x]."</strong></i>";
echo "</span>";
echo "</td>";
}


echo "</tr>";

///////////////////////////////////////////////


echo "<tr>";

$yearMin = 1 * $years;
$yearMax = 50 * $years;
$yearLSMax = 12 * $years;

$genNum3 = [];
$genNumLS3 = [];
$genNum3 = gen_num($yearMin, $yearMax, $years);
$genNumLS3 = gen_num_ls($yearMin, $yearLSMax, $years);

echo "<tr>";

$arrlength = count($genNum3);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#DDDDDD;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNum3[$x]."</strong></i>";
echo "</span>";
echo "</td>";

}

$arrlength = count($genNumLS3);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#FFF4A4 ;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNumLS3[$x]."</strong></i>";
echo "</span>";
echo "</td>";
}


echo "</tr>";

///////////////////////////////////////////////

echo "<tr>";

$sMin = 1 * $sumall;
$sMax = 50 * $sumall;
$sLSMax = 12 * $sumall;

$genNum4 = [];
$genNumLS4 = [];
$genNum4 = gen_num($sMin, $sMax, $sumall);
$genNumLS4 = gen_num_ls($sMin, $sLSMax, $sumall);

echo "<tr>";

$arrlength = count($genNum4);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#DDDDDD;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNum4[$x]."</strong></i>";
echo "</span>";
echo "</td>";

}

$arrlength = count($genNumLS4);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#FFF4A4 ;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNumLS4[$x]."</strong></i>";
echo "</span>";
echo "</td>";

}


echo "</tr>";

///////////////////////////////////////////////


echo "<tr>";

$dMin = 1 * $diff;
$dMax = 50 * $diff;
$dLSMax = 12 * $diff;

$genNum5 = [];
$genNumLS5 = [];
$genNum5 = gen_num($dMin, $dMax, $diff);
$genNumLS5 = gen_num_ls($dMin, $dLSMax, $diff);

echo "<tr>";

$arrlength = count($genNum5);
for($x = 0; $x < $arrlength; $x++) {
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#DDDDDD;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNum5[$x]."</strong></i>";
echo "</span>";
echo "</td>";


}

$arrlength = count($genNumLS5);
for($x = 0; $x < $arrlength; $x++) {
//  echo "<td>".$genNumLS5[$x]."</td>";
echo "<td class='text-start'>";
echo "<span class='fa-stack'>";
echo "<i class='far fa-circle fa-stack-2x'  style='color:#FFF4A4 ;'></i>";
echo "<i class='fa-stack-1x'><strong>".$genNumLS5[$x]."</strong></i>";
echo "</span>";
echo "</td>";

}






echo "</tr>";

///////////////////////////////////////////////




echo "</tbody>";
echo "</table>";

echo "</div>";
echo "</div>";


}



}
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}


?>

<?php
 require "../../template/template_footer_basic.php";
?>


<script>
$(document).ready(function() {
    $('#table1').DataTable( {
        dom: 'Bfrtip',
        searching: true,
	paging: true,
        ordering: true,
        info: true,
        pageLength: 20,
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'Random_Names',
		text: 'Export to Excel'
            },
        ]
    } );
} );
</script>


 <script src="../../assets/js/dataTable/jquery.dataTables.min.js"></script>
 <script src="../../assets/js/dataTable/dataTables.buttons.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.flash.min.js"></script>
 <script src="../../assets/js/dataTable/jszip.min.js"></script>
 <script src="../../assets/js/dataTable/pdfmake.min.js"></script>
 <script src="../../assets/js/dataTable/vfs_fonts.js"></script>
 <script src="../../assets/js/dataTable/buttons.html5.min.js"></script>
 <script src="../../assets/js/dataTable/buttons.print.min.js"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js" integrity="sha512-FHZVRMUW9FsXobt+ONiix6Z0tIkxvQfxtCSirkKc5Sb4TKHmqq1dZa8DphF0XqKb3ldLu/wgMa8mT6uXiLlRlw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


</body>
</html>
