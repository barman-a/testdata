<?php
 require "../../template/template_header.php";

echo "<title>Contact Us | ".$home."</title>";

 require "../../template/template_body_first.php";

echo "<div class='col-6'>
     <h3> Contact Us </h3>
     <h6>We would like to hear from you. Please contact us if you have any queries or suggestions </h6>
    </div>";

 require "../../template/template_body_second.php";
?>



<?php


if($_POST){
try{

$name = $_POST['name'];
$e_mail = $_POST['email'];
$msg = $_POST['msg'];


if(preg_match('/^[a-zA-Z0-9 ]+$/', $name) == 1 && preg_match('/^[a-zA-Z0-9.-_@ ]+$/', $e_mail) == 1 && preg_match('/^[a-zA-Z0-9.?,! ]+$/', $name) == 1 && strlen($name) < 50 && strlen($e_mail) < 80 && strlen($msg) < 1000){

$targetEmail = "arghya.barman@fujifilm.com";

////// Sending an email to the manager /////
$to = $targetEmail;
$subject = "Message From " .$name;
$headers = "From: hrcourse_donotreply@fujifilm.com\r\n";

if(mail($to, $subject, $msg, $headers)){
echo "Thank you for contacting us";
}else{
echo "Something wrong!";
}

////// End of sending email /////
}else{
echo "<p style='color:red;'> Sorry, unable to send message! Unacceptable character found</p>";
}

}
    // show error
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }

}


?>

<div class="row">
<div class=" col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6 card card-body text-justify m-2 ">

<form action="" method="post">

<h6> Name </h6>
<input type="text" id="firstname" name="name" class="form-control" placeholder="Full name" required value='<?php echo $name; ?>'>
<h6> Email </h6>
<input type="email" id="email" name="email" class="form-control" placeholder="Email address" required value='<?php echo $e_mail; ?>' >
<h6> Message </h6>
<textarea id="msg" name="msg" placeholder="Message" rows="5" class="form-control" style="width: 100%; resize: none;  height: 240px;" required><?php echo $msg; ?></textarea>
<input type='submit' value='Send Message' class='btn btn-secondary btn-xl btn-lg btn-md btn-sm btn-xs form-control mt-2' />

</form>

</div>

<div class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col-xs-5 card card-body text-justify m-2 ">

<img src= "../../assets/image/mail.jpg" />

</div>

<?php
 require "../../template/template_footer_basic.php";
?>


</body>
</html>
